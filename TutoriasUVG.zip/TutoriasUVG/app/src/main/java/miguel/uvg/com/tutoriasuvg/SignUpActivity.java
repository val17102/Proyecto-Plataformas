package miguel.uvg.com.tutoriasuvg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {
    DatabasHelper helper = new DatabasHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Button crear_btn = (Button) findViewById(R.id.crear_btn);
        final EditText correo_EditText = (EditText) findViewById(R.id.correo_EditText);
        final EditText pass_EditText = (EditText) findViewById(R.id.pass_EditText);
        final EditText confi_EditText = (EditText) findViewById(R.id.confi_EditText);
        crear_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                final String correoStr = correo_EditText.getText().toString();
                final String pass1Str = pass_EditText.getText().toString();
                final String pass2Str = confi_EditText.getText().toString();
                if (pass1Str.equals(pass2Str)){
                    Contact c = new Contact();
                    c.setEmail(correoStr);
                    c.setPass(pass1Str);
                    helper.insertContact(c);
                    Intent startIntent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(startIntent);
                }else
                {
                    Toast pass = Toast.makeText(getBaseContext() , "Contraseñas no son iguales", Toast.LENGTH_LONG);
                    pass.show();
                }
            }
        });
    }
}
