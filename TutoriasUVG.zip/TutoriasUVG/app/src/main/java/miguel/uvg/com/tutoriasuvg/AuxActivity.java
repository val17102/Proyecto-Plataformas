package miguel.uvg.com.tutoriasuvg;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class AuxActivity extends AppCompatActivity {
    DatabasHelper2 helper = new DatabasHelper2(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aux);
        ListView tutores_ListView = (ListView) findViewById(R.id.tutores_ListView);
        Bundle extras = getIntent().getExtras();
        ArrayList<String> info = new ArrayList<String>();
        //if(extras != null){
            String curso = extras.getString("KEY");
            Log.d("mylog", curso);
            ArrayList<Tutor> tutores = helper.searchTutor(curso);
            for (int i = 0; i<tutores.size(); i++){
                info.add("Nombre: "+tutores.get(i).getNombre()+" Horario "+tutores.get(i).getHorario());
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,info);
            tutores_ListView.setAdapter(adapter);

       // }

    }
}
