package miguel.uvg.com.tutoriasuvg;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabasHelper2 extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "tutores.db";
    private static final String TABLE_NAME = "tutores";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NOMBRE = "nombre";
    private static final String COLUMN_CURSO = "curso";
    private static final String COLUMN_HORARIO = "horario";
    private static final String COLUMN_CONTACTO = "contacto";
    SQLiteDatabase db;

    private static final String TABLE_CREATE = "create table "+TABLE_NAME+" (id int primary key not null , nombre text not null, curso text not null ,"+
    " horario text not null , contacto text not null)";

    public DatabasHelper2(Context context){
        super(context, DATABASE_NAME , null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS "+TABLE_NAME;
        db.execSQL(query);
        this.onCreate(db);
    }

    public  void insertTutor(Tutor t){
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        String query = "select * from "+TABLE_NAME;
        Cursor cursor = db.rawQuery(query,null);
        int count = cursor.getCount();
        values.put(COLUMN_ID, count);
        values.put(COLUMN_NOMBRE, t.getNombre());
        values.put(COLUMN_CURSO, t.getCurso());
        values.put(COLUMN_HORARIO, t.getHorario());
        values.put(COLUMN_CONTACTO, t.getContacto());
        db.insert(TABLE_NAME , null , values);
        db.close();
    }

    public ArrayList<Tutor> searchTutor(String curso){
        db = this.getReadableDatabase();
        String query = "select id, curso, nombre, horario, contacto from "+TABLE_NAME;
        Cursor cursor = db.rawQuery(query,null);
        String a,b,c,d,e;
        ArrayList<Tutor> tutores = new ArrayList<Tutor>();
        b = "Correo o Contraseña Incorrecta";
        Tutor temp = new Tutor();
        if (cursor.moveToFirst())
        {
            do{

                b = cursor.getString(1);
                if (b.equals(curso)){
                    a = cursor.getString(0);
                    c = cursor.getString(2);
                    d = cursor.getString(3);
                    e = cursor.getString(4);
                    Log.d("mylog",b);
                    temp.setId(Integer.parseInt(a));
                    temp.setCurso(b);
                    temp.setNombre(c);
                    temp.setHorario(d);
                    temp.setContacto(e);
                    tutores.add(temp);
                }
            }while(cursor.moveToNext());
        }
        return tutores;
    }
}
